package org.akaza.openclinica.domain.enumsupport;

public interface CodedEnum {

    public Integer getCode();

}