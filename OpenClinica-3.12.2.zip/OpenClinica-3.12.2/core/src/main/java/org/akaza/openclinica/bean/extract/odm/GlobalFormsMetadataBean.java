package org.akaza.openclinica.bean.extract.odm;

public class GlobalFormsMetadataBean extends MetaDataReportBean {

	
	public GlobalFormsMetadataBean(){
		super();
	}
}
